package ast;

public interface ASTNode {
	
	public int getLine();
	public int getColum();
	
}
