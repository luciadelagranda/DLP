package ast;

public abstract class StatementAbstract extends ASTNodeAbstract implements Statement {

	public StatementAbstract(int i, int j) {
		super(i, j);
	}

}
