package ast;

import errorhandler.EH;

public class ErrorType extends ASTNodeAbstract implements Type{
	
	private String message;

	public ErrorType(int line, int column) {
		super(line, column);
	}
	
	public ErrorType(int line, int column,ASTNode node, String message) {
		this(line,column);
		this.message= message;
		EH.getEH().addError(this);
	}

	@Override
	public String toString() {
		return "ERROR: " + message ;
	}
	
	

}
