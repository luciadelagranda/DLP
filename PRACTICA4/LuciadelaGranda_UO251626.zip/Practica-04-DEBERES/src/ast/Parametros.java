package ast;

public class Parametros extends ASTNodeAbstract{

	public String nombre;
	public Type tipo;
	
	
	public Parametros(int i, int j, String nombre, Type tipo) {
		super(i, j);
		this.nombre=nombre;
		this.tipo=tipo;
	}
	
	
}
