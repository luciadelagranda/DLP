package ast;

import java.util.List;

public class InputStatement extends StatementAbstract implements Statement{

	private Object expressions;

	public InputStatement(int line, int column, List<Expression> expressions) {
		super(line,column);
		this.expressions = expressions;
	}

	@Override
	public String toString() {
		return "InputStatement [expressions=" + expressions + "]";
	}

}
