package ast;

import java.util.List;

public class Body extends ASTNodeAbstract{

	private List<VariableDef> variables;
	private List<Statement> statements;

	public Body(int i, int j, List<VariableDef> variables, List<Statement> statements) {
		super(i, j);
		this.variables = variables;
		this.statements   = statements;
		
	}

	@Override
	public String toString() {
		return "Body [variables=" + variables + ", statements=" + statements + "]";
	}
	
	

}
