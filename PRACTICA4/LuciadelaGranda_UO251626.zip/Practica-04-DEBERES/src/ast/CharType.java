package ast;

public class CharType extends ASTNodeAbstract implements Type{
	
	private static CharType insta;
	
	private CharType(int line, int column) {
		super(line,column);
	}
	
	public static CharType CharTypeInstance(int line, int column) {
		insta = new CharType(line, column);
		return insta;
	}
	
	@Override
	public String toString() {
		return "CharType [char]";
	}
}	
