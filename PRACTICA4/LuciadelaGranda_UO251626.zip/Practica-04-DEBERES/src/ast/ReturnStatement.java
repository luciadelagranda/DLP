package ast;

public class ReturnStatement extends StatementAbstract implements Statement {

	private Expression expression;

	public ReturnStatement(int line, int column, Expression expression) {
		super(line,column);
		this.expression = expression;
	}

	@Override
	public String toString() {
		return "ReturnStatement [expression=" + expression + "]";
	}

	

}
