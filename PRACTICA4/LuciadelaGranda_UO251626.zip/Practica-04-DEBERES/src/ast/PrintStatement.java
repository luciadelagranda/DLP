package ast;

import java.util.List;

public class PrintStatement extends StatementAbstract implements Statement{

	private List<Expression> expressions;

	public PrintStatement(int line, int column, List<Expression> expressions) {
		super(line,column);
		this.expressions = expressions;
	}

	@Override
	public String toString() {
		return "PrintStatement [expressions=" + expressions + "]";
	}

}
