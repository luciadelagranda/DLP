package ast;

public class IntType extends ASTNodeAbstract implements Type{
	
	private static IntType insta;
	
	
	private IntType(int line, int column) {
		super(line,column);
	}
	
	public static IntType IntTypeInstance(int line, int column) {
		insta = new IntType(line, column);
		return insta;
	}
	
	@Override
	public String toString() {
		return "IntType [int]";
	}

}
