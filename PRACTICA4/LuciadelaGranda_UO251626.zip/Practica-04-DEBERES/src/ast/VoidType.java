package ast;

public class VoidType extends ASTNodeAbstract implements Type{

	private static VoidType insta;
	
	
	private VoidType(int line, int column) {
		super(line,column);
	}
	
	public static VoidType VoidTypeInstance(int line, int column) {
		insta = new VoidType(line, column);
		return insta;
	}
	
	@Override
	public String toString() {
		return "VoidType [void]";
	}
}
