package ast;

public abstract class ExpressionAbstract extends ASTNodeAbstract implements Expression {

	public ExpressionAbstract(int i, int j) {
		super(i, j);
	}

}
