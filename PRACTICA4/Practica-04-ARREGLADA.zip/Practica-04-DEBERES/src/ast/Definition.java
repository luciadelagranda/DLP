package ast;

public interface Definition {
	
	public String getName();
	public Type getType();
}
