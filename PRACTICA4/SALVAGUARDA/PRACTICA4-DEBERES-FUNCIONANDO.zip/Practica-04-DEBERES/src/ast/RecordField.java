package ast;

public class RecordField extends ASTNodeAbstract {

	private Variable name;
	private Type type;

	public RecordField(int i, int j, Variable name, Type type) {
		super(i, j);
		this.name = name;
		this.type = type;
	}

	@Override
	public String toString() {
		return "RedordField [name=" + name + ", type=" + type + "]";
	}

}
