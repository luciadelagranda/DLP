package ast;

public class DoubleType extends ASTNodeAbstract implements Type{
	
	private static DoubleType insta;
	
	private DoubleType(int line, int column) {
		super(line,column);
	}
	
	public static DoubleType DoubleTypeInstance(int line, int column) {
		insta = new DoubleType(line, column);
		return insta;
	}
	
	@Override
	public String toString() {
		return "DoubleType [double]";
	}
}
