package ast;

public class ParametroDef extends ASTNodeAbstract implements ASTNode{

	private String name;
	private Type type;

	public ParametroDef(int line, int column, String string, Type type) {
		super(line,column);
		this.name = string;
		this.type = type;
	}

	@Override
	public String toString() {
		return "ParametroDef [name=" + name + ", type=" + type + "]";
	}

}
