package ast;


public class FuncionDef extends ASTNodeAbstract implements Definition {

	private String name;
	private FuncionType parametros;
	private Body body;

	public FuncionDef(int line, int column, String string, FuncionType funcionType,
			Body body) {
		super(line, column);
		this.name = string;
		this.parametros = funcionType;
		this.body = body;
	}


	@Override
	public String getName() {
		return name;
	}


	@Override
	public String toString() {
		return "FuncionDef [name=" + name + ", parametros=" + parametros + ", body=" + body + "]";
	}


	@Override
	public Type getType() {
		return parametros.getType();
	}

	

	

}
